<?php
/**
 * Image upload field which uses plupload library to drag and drop files to upload.
 */
class MASHSB_RWMB_Plupload_Image_Field extends MASHSB_RWMB_Image_Upload_Field {}
