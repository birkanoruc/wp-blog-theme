Translations have moved to
https://translate.wordpress.org/projects/wp-plugins/wp-ulike

Thank you for your contribution.